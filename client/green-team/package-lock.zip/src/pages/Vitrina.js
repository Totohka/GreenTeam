import Items from "../widgets/Items/Items";

function Vitrina(){
    return(
        <div>
            <Items></Items>
        </div>
    )
}
export default Vitrina;
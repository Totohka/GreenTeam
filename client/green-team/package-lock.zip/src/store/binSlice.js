import { createSlice } from "@reduxjs/toolkit";

export const binSlice = createSlice({
    name:'bin',
    initialState:{
        items:[],
        summ:0.0
    },
    reducers:{
        addItemToBin:(state, action)=>{
            let item = new Object();
            item = {...action.payload};
            item.count=1;
            item.subsum=item.price;
            state.items=state.items.concat(item);
            state.summ+=item.price;
        },
        incrementCount: (state, action) => {
            debugger;
            console.log(action.payload);
            let id = action.payload;
            console.log(id);
            console.log("State");
            console.log(state.items.filter(item=>item.id==id));
            let countId = state.items.find(item => item.id==id);
            console.log(countId);
            state.items[countId].count+=1;
            state.items[countId].subsum+=state[countId].items.price;
            state.summ+=state[countId].items.price;
        },
        decrementCount: (state,action)=>{
            let id = action.payload;
            let countId = state.items.find((item) => item.id==id);
            
            if (state.items.count[countId]==1)
                state.items.count[countId]=1;
            else {
                state.items.count[countId]-=1;
                state.items.subsum[countId]-=state.items[countId].price;
                state.summ-=state.items[countId].price;
            }
        },
    }
})
export const {addItemToBin, incrementCount, decrementCount} = binSlice.actions;
export default binSlice.reducer;